/**
 * Ultra Vehicle Card Version
 * v3.0.0
 * 
 * This file is auto-generated from src/version.ts
 * DO NOT MODIFY DIRECTLY
 */

let version = "undefined";

function setVersion(value) {
  version = value;
}

// Set default version (will be overridden by card)
setVersion('3.0.0');

export { version, setVersion };